﻿using System.Collections;
using UnityEngine;

namespace Game
{
    public class CameraFollow : MonoBehaviour
    {
        public Transform target;
        public float smoothSpeed = 0.3f;

        private Vector3 _targetPosition;
        private Vector3 _basePosition;
        private bool _isMoving;
    
        private void Start()
        {
            _basePosition = transform.position;    #сохранение начальной позиции камеры
        
            ResetCamera();                         #вызов метода ResetCamera(), который устанавливает камеру в начальную позици
        }

        private void LateUpdate()
        {
            var position = transform.position;      #сохранение начальной позиции камеры
            if (target.position.y <= _targetPosition.y) return;   #если вертикальная позиция цели меньше или равна текущей целевой позиции камеры, то камера не движется. Если условие не проходит, то:

            var newPos = new Vector3(position.x, target.position.y, position.z);    #создается новая позиция, где Х - текущая позиция камеры, y - позиция персонажа
            FollowTarget(newPos);                                                   #Вызов метода движения камеры
        }

        private void FollowTarget(Vector3 targetPos)
        {
            _targetPosition = targetPos;
            if(!_isMoving) StartCoroutine(Follow());
        }

        private IEnumerator Follow()
        {
            _isMoving = true;
            while (Vector3.Distance(transform.position, _targetPosition) > 0.1f)   #цикл выполняется, пока расстояние между камерой и целью больше 0.1f
            {
                transform.position = Vector3.Lerp(transform.position, _targetPosition, Time.deltaTime * smoothSpeed);  #плавное перемещение камеры к цели
                yield return null;
            }
            _isMoving = false;
        }

        public void ResetCamera()
        {
            _targetPosition = _basePosition;
            transform.position = _basePosition;
        }
    }
}
