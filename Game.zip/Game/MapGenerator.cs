﻿using System.Collections;
using System.Collections.Generic;
using Platforms;
using ScriptableObjects;
using Tools;
using UnityEngine;

namespace Game
{
    public class MapGenerator : MonoBehaviour
    {
        public Transform playerTransform;      #ссылка на игрока, необходимая для определения позиции генерации платформ.
        public FloatReference playerScore;     # ссылка на Scriptable Object с очками игрока.

        public Transform platformParent;       #ссылка на родитель, к которому будут привязаны все сгенерированные платформы

        public Platform firstPlatform;         #ссылка  первой платформы.
        public List<Platform> platforms;       #список  различных платформ
        public List<Item> items;               #список предметов

        public float itemProbability = 0.1f;   #вероятность появления предмета на платформе

        public float overheadDistance = 10f;   #расстояние от игрока до верхней границы генерации платформ
        public float maxDistance = 20f;        #максимальное расстояние генерации платформ за один раз.

        private float _yGeneration;            #текущая координата Y, до которой были сгенерированы платформы
        private float _lastPlatformY;          #координата Y последней сгенерированной платформы

        private float _basePlatformY;          #сохранение начального значения _lastPlatformY  для сброса генерации
        private float _baseY;                  #сохранение начального значения _yGeneration для сброса генерации

        private void Start()
        {
            _basePlatformY = _lastPlatformY;
            _baseY = _yGeneration;
        }

        private void Update()  #метод обновления каждого кадра
        {
            UpdateMap();
        }

        private void UpdateMap()  #Определяет, нужно ли генерировать новые платформы, проверяя расстояние от игрока до _yGeneration. Если нужно, вызывает GeneratePartialMap().
        {
            var baseY = playerTransform.position.y;  
            GeneratePartialMap(baseY, maxDistance); 
        }

        private void GeneratePartialMap(float baseY, float maxY)   #Определяет новую границу генерации платформ и вызывает функцию генерации платформ
        {
            if (baseY + overheadDistance <= _yGeneration) return;

            _yGeneration = baseY + overheadDistance;

            var max = _yGeneration + maxY;
            GeneratePlatforms(max);
        }

        private void GeneratePlatforms(float maxY)  #Вызывает в цикле генерацию платформ, пока персонаж не достигнет MaxY (max_distance)
        {
            while (_lastPlatformY < maxY)
            {
                GeneratePlatform();
            }
        }

        private void SpawnFirstPlatform()  #Создает первую платформу в позиции (0, 0, 0) и привязывает к platformParent.
        {
            var platformPrefab = firstPlatform.prefab;
            Instantiate(platformPrefab, Vector3.zero, Quaternion.identity, platformParent);
        }

        private void GeneratePlatform()  # Генерация платформ
        {
            var difficulty = playerScore / 1000;  
            var platformObject = platforms.FindAll(p => p.difficulty <= difficulty).GetRandom();  
			
			
		
			
            var platformPrefab = platformObject.prefab;  
            var xRange = platformObject.xRange;
            var yRange = platformObject.yRange;
        
            var xRandom = xRange.Random();
            var yRandom = _lastPlatformY + yRange.Random();
        
            var pos = new Vector2(xRandom, yRandom);


            var platform = Instantiate(platformPrefab, pos, Quaternion.identity, platformParent);
            var platformScript = platform.GetComponent<BasePlatform>();

            platformScript.Init();

            var movingPlatform = platform.GetComponent<MovingPlatform>();
            var yPlatformRange = movingPlatform == null ? 0f : movingPlatform.YRange;
            
            _lastPlatformY = yRandom + yPlatformRange;
            
            if (Random.value <= itemProbability && platformObject.hasItem)
            {
                GenerateItem(platform.transform);
            }
        }

        private void GenerateItem(Transform platform)
        {
            var itemObject = items.GetRandom();
            var itemPrefab = itemObject.prefab;
            var xRange = itemObject.xRange;

            var xRandom = xRange.Random();
            var platformPos = platform.position;
            platformPos.x += xRandom;

            Instantiate(itemPrefab, platformPos, Quaternion.identity, platform);
        }

        public void DeletePlatforms()  #Удаление платформ, которые персонаж пролетел
        {
            foreach (Transform child in platformParent)
            {
                Destroy(child.gameObject);
            }   
        }

        public void ResetMap()
        {
            DeletePlatforms();

            SpawnFirstPlatform();
            
            _lastPlatformY = _basePlatformY;
            _yGeneration = _baseY;

            GeneratePlatforms(overheadDistance);
        }
    
    }
}
